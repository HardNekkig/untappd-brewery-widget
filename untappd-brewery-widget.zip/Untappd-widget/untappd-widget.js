( function () {
    'use strict';

    function initCarousel( carousel ) {
        var viewport = carousel.querySelector( '.utw-carousel-viewport' );
        var track    = viewport && viewport.querySelector( '.untappd-checkins' );

        if ( ! track ) { return; }

        var items   = track.querySelectorAll( '.untappd-checkin' );
        var visible = Math.max( 1, parseInt( carousel.dataset.visible, 10 ) || 3 );
        var total   = items.length;
        var current = 0;
        var max     = Math.max( 0, total - visible );

        function itemWidth() {
            return viewport.offsetWidth / Math.min( visible, total );
        }

        function update() {
            track.style.transform = 'translateX(-' + ( current * itemWidth() ) + 'px)';
        }

        function advance() {
            current = current >= max ? 0 : current + 1;
            viewport.style.opacity = '0.5';
            update();
            setTimeout( function () { viewport.style.opacity = '1'; }, 260 );
        }

        var timer = setInterval( advance, 3000 );

        // Pause on hover.
        carousel.addEventListener( 'mouseenter', function () { clearInterval( timer ); } );
        carousel.addEventListener( 'mouseleave', function () { timer = setInterval( advance, 3000 ); } );

        var resizeTimer;
        window.addEventListener( 'resize', function () {
            clearTimeout( resizeTimer );
            resizeTimer = setTimeout( update, 80 );
        } );

        update();
    }

    document.querySelectorAll( '.utw-carousel' ).forEach( initCarousel );
} )();
