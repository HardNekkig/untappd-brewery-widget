<?php
/**
 * Plugin Name:  Untappd Brewery Widget
 * Description:  Displays the latest check-ins for a brewery fetched live from the Untappd API.
 * Version:      1.3.0
 * Requires PHP: 7.4
 * License:      GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// =============================================================================
// Shared helpers
// =============================================================================

function untappd_widget_defaults(): array {
    return [
        'brewery_id'    => '',
        'client_id'     => '',
        'client_secret' => '',
        'count'            => 5,
        'carousel_visible' => 3,
        'min_rating'       => 3.0,
        'cache_minutes'    => 5,
        'show'          => [
            'avatar'     => 1,
            'username'   => 1,
            'timestamp'  => 1,
            'beer_label' => 1,
            'beer_name'  => 1,
            'beer_style' => 1,
            'rating'     => 1,
            'comment'    => 1,
            'photo'      => 1,
        ],
        'colors' => [
            'amber'     => '#f5a623',
            'border'    => 'rgba(0,0,0,0.10)',
            'separator' => 'rgba(0,0,0,0.07)',
            'hover_bg'  => 'rgba(0,0,0,0.03)',
            'radius'    => '8px',
        ],
    ];
}

function untappd_widget_options(): array {
    $saved    = get_option( 'untappd_widget_options', [] );
    $defaults = untappd_widget_defaults();

    $options             = array_merge( $defaults, $saved );
    $options['show']     = array_merge( $defaults['show'],   (array) ( $saved['show']   ?? [] ) );
    $options['colors']   = array_merge( $defaults['colors'], (array) ( $saved['colors'] ?? [] ) );

    return $options;
}

// =============================================================================
// Settings page
// =============================================================================

class Untappd_Widget_Settings_Page {

    const OPTION = 'untappd_widget_options';
    const PAGE   = 'untappd-widget-settings';
    const NONCE  = 'untappd_widget_flush_cache';

    public function __construct() {
        add_action( 'admin_menu',            [ $this, 'add_menu' ] );
        add_action( 'admin_init',            [ $this, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
        add_action( 'admin_post_untappd_flush_cache', [ $this, 'handle_flush_cache' ] );
    }

    public function add_menu() {
        add_options_page(
            __( 'Untappd Widget Settings', 'untappd-widget' ),
            __( 'Untappd Widget', 'untappd-widget' ),
            'manage_options',
            self::PAGE,
            [ $this, 'render_page' ]
        );
    }

    public function enqueue_admin_assets( string $hook ) {
        if ( $hook !== 'settings_page_' . self::PAGE ) {
            return;
        }
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script( 'wp-color-picker' );
        wp_add_inline_script( 'wp-color-picker', 'jQuery(function($){ $(".utw-color-picker").wpColorPicker(); });' );
    }

    public function register_settings() {
        register_setting( self::OPTION, self::OPTION, [ $this, 'sanitize' ] );
    }

    public function sanitize( $input ): array {
        $defaults = untappd_widget_defaults();
        $clean    = [];

        $clean['brewery_id']    = absint( $input['brewery_id'] ?? 0 );
        $clean['client_id']     = sanitize_text_field( $input['client_id']     ?? '' );
        $clean['client_secret'] = sanitize_text_field( $input['client_secret'] ?? '' );
        $clean['count']            = min( 25, max( 1, absint( $input['count']            ?? 5  ) ) );
        $clean['carousel_visible'] = min(  5, max( 1, absint( $input['carousel_visible'] ?? 3  ) ) );
        $clean['min_rating']       = round( min( 5.0, max( 0.0, (float) ( $input['min_rating'] ?? 3.0 ) ) ), 1 );
        $clean['cache_minutes']    = min( 1440, max( 1, absint( $input['cache_minutes']  ?? 5  ) ) );

        foreach ( array_keys( $defaults['show'] ) as $field ) {
            $clean['show'][ $field ] = ! empty( $input['show'][ $field ] ) ? 1 : 0;
        }

        foreach ( array_keys( $defaults['colors'] ) as $field ) {
            $val = sanitize_text_field( $input['colors'][ $field ] ?? $defaults['colors'][ $field ] );
            $clean['colors'][ $field ] = $val ?: $defaults['colors'][ $field ];
        }

        // Flush all cached check-ins when settings are saved
        $this->flush_all_caches();

        return $clean;
    }

    public function handle_flush_cache() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Unauthorized' );
        }
        check_admin_referer( self::NONCE );
        $this->flush_all_caches();
        wp_redirect( add_query_arg(
            [ 'page' => self::PAGE, 'cache_flushed' => '1' ],
            admin_url( 'options-general.php' )
        ) );
        exit;
    }

    private function flush_all_caches() {
        global $wpdb;
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
            '_transient_untappd_checkins_%',
            '_transient_timeout_untappd_checkins_%'
        ) );
    }

    // -------------------------------------------------------------------------
    // Settings page HTML
    // -------------------------------------------------------------------------

    public function render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $opts = untappd_widget_options();
        ?>
        <div class="wrap utw-wrap">

            <h1 style="display:flex;align-items:center;gap:10px;">
                <span style="color:#f5a623;font-size:1.4em;line-height:1;">&#127866;</span>
                <?php esc_html_e( 'Untappd Widget Settings', 'untappd-widget' ); ?>
            </h1>

            <?php if ( isset( $_GET['settings-updated'] ) ) : ?>
                <div class="notice notice-success is-dismissible">
                    <p><?php esc_html_e( 'Settings saved.', 'untappd-widget' ); ?></p>
                </div>
            <?php endif; ?>
            <?php if ( isset( $_GET['cache_flushed'] ) ) : ?>
                <div class="notice notice-success is-dismissible">
                    <p><?php esc_html_e( 'Cache flushed — fresh data will be fetched on next page load.', 'untappd-widget' ); ?></p>
                </div>
            <?php endif; ?>

            <form method="post" action="options.php">
                <?php settings_fields( self::OPTION ); ?>

                <!-- ── API Credentials ──────────────────────────────────── -->
                <div class="utw-card">
                    <h2 class="utw-card__title"><?php esc_html_e( 'API Credentials', 'untappd-widget' ); ?></h2>
                    <p class="description">
                        <?php printf(
                            /* translators: %s: link to Untappd API registration */
                            esc_html__( 'Register your application at %s to get a Client ID and Client Secret.', 'untappd-widget' ),
                            '<a href="https://untappd.com/api/register" target="_blank" rel="noopener">untappd.com/api/register</a>'
                        ); ?>
                    </p>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row">
                                <label for="utw_brewery_id"><?php esc_html_e( 'Brewery ID', 'untappd-widget' ); ?></label>
                            </th>
                            <td>
                                <input type="number" id="utw_brewery_id"
                                       name="untappd_widget_options[brewery_id]"
                                       value="<?php echo esc_attr( $opts['brewery_id'] ); ?>"
                                       min="1" step="1" class="regular-text" placeholder="e.g. 431566" />
                                <p class="description">
                                    <?php esc_html_e( 'Found in the brewery\'s Untappd URL — e.g. untappd.com/brewery/431566 → 431566', 'untappd-widget' ); ?>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="utw_client_id"><?php esc_html_e( 'Client ID', 'untappd-widget' ); ?></label>
                            </th>
                            <td>
                                <input type="text" id="utw_client_id"
                                       name="untappd_widget_options[client_id]"
                                       value="<?php echo esc_attr( $opts['client_id'] ); ?>"
                                       class="regular-text" autocomplete="off" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="utw_client_secret"><?php esc_html_e( 'Client Secret', 'untappd-widget' ); ?></label>
                            </th>
                            <td>
                                <input type="password" id="utw_client_secret"
                                       name="untappd_widget_options[client_secret]"
                                       value="<?php echo esc_attr( $opts['client_secret'] ); ?>"
                                       class="regular-text" autocomplete="new-password" />
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- ── Fetch Settings ───────────────────────────────────── -->
                <div class="utw-card">
                    <h2 class="utw-card__title"><?php esc_html_e( 'Fetch Settings', 'untappd-widget' ); ?></h2>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row">
                                <label for="utw_count"><?php esc_html_e( 'Number of check-ins', 'untappd-widget' ); ?></label>
                            </th>
                            <td>
                                <input type="number" id="utw_count"
                                       name="untappd_widget_options[count]"
                                       value="<?php echo esc_attr( $opts['count'] ); ?>"
                                       min="1" max="25" class="small-text" />
                                <p class="description">
                                    <?php esc_html_e( '1–25 (Untappd API limit per request).', 'untappd-widget' ); ?>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="utw_carousel_visible"><?php esc_html_e( 'Visible cards at once', 'untappd-widget' ); ?></label>
                            </th>
                            <td>
                                <input type="number" id="utw_carousel_visible"
                                       name="untappd_widget_options[carousel_visible]"
                                       value="<?php echo esc_attr( $opts['carousel_visible'] ); ?>"
                                       min="1" max="5" class="small-text" />
                                <p class="description">
                                    <?php esc_html_e( 'How many check-in cards to show side by side in the carousel (1–5).', 'untappd-widget' ); ?>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="utw_min_rating"><?php esc_html_e( 'Minimum rating', 'untappd-widget' ); ?></label>
                            </th>
                            <td>
                                <input type="number" id="utw_min_rating"
                                       name="untappd_widget_options[min_rating]"
                                       value="<?php echo esc_attr( $opts['min_rating'] ); ?>"
                                       min="0" max="5" step="0.5" class="small-text" />
                                <p class="description">
                                    <?php esc_html_e( 'Only show check-ins with a rating at or above this value (0 = show all). Range: 0–5 in 0.5 steps.', 'untappd-widget' ); ?>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="utw_cache"><?php esc_html_e( 'Cache duration', 'untappd-widget' ); ?></label>
                            </th>
                            <td>
                                <input type="number" id="utw_cache"
                                       name="untappd_widget_options[cache_minutes]"
                                       value="<?php echo esc_attr( $opts['cache_minutes'] ); ?>"
                                       min="1" max="1440" class="small-text" />
                                <?php esc_html_e( 'minutes', 'untappd-widget' ); ?>
                                <p class="description">
                                    <?php esc_html_e( 'How long API results are cached before a fresh request is made. 1–1440 min (max 24 h).', 'untappd-widget' ); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- ── Display Fields ───────────────────────────────────── -->
                <div class="utw-card">
                    <h2 class="utw-card__title"><?php esc_html_e( 'Display Fields', 'untappd-widget' ); ?></h2>
                    <p class="description"><?php esc_html_e( 'Choose which information to show for each check-in.', 'untappd-widget' ); ?></p>
                    <table class="form-table" role="presentation">
                        <?php
                        $fields = [
                            'avatar'     => __( 'User avatar', 'untappd-widget' ),
                            'username'   => __( 'User name', 'untappd-widget' ),
                            'timestamp'  => __( 'Check-in time', 'untappd-widget' ),
                            'beer_label' => __( 'Beer label image', 'untappd-widget' ),
                            'beer_name'  => __( 'Beer name', 'untappd-widget' ),
                            'beer_style' => __( 'Beer style', 'untappd-widget' ),
                            'rating'     => __( 'Rating (stars)', 'untappd-widget' ),
                            'comment'    => __( 'Check-in comment', 'untappd-widget' ),
                            'photo'      => __( 'Check-in photo', 'untappd-widget' ),
                        ];
                        foreach ( $fields as $key => $label ) :
                        ?>
                        <tr>
                            <th scope="row"><?php echo esc_html( $label ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox"
                                           name="untappd_widget_options[show][<?php echo esc_attr( $key ); ?>]"
                                           value="1"
                                           <?php checked( ! empty( $opts['show'][ $key ] ) ); ?> />
                                    <?php esc_html_e( 'Show', 'untappd-widget' ); ?>
                                </label>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>

                <!-- ── Colors ───────────────────────────────────────────── -->
                <div class="utw-card">
                    <h2 class="utw-card__title"><?php esc_html_e( 'Colors', 'untappd-widget' ); ?></h2>
                    <p class="description">
                        <?php esc_html_e( 'Customise the widget\'s colour scheme. Accepts hex (#rrggbb) or rgba() values.', 'untappd-widget' ); ?>
                    </p>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row">
                                <label for="utw_color_amber"><?php esc_html_e( 'Star / accent color', 'untappd-widget' ); ?></label>
                            </th>
                            <td>
                                <input type="text" id="utw_color_amber"
                                       class="utw-color-picker"
                                       name="untappd_widget_options[colors][amber]"
                                       value="<?php echo esc_attr( $opts['colors']['amber'] ); ?>"
                                       data-default-color="#f5a623" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="utw_color_border"><?php esc_html_e( 'Border color', 'untappd-widget' ); ?></label>
                            </th>
                            <td>
                                <input type="text" id="utw_color_border"
                                       name="untappd_widget_options[colors][border]"
                                       value="<?php echo esc_attr( $opts['colors']['border'] ); ?>"
                                       class="regular-text" placeholder="rgba(0,0,0,0.10)" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="utw_color_separator"><?php esc_html_e( 'Separator color', 'untappd-widget' ); ?></label>
                            </th>
                            <td>
                                <input type="text" id="utw_color_separator"
                                       name="untappd_widget_options[colors][separator]"
                                       value="<?php echo esc_attr( $opts['colors']['separator'] ); ?>"
                                       class="regular-text" placeholder="rgba(0,0,0,0.07)" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="utw_color_hover"><?php esc_html_e( 'Hover background', 'untappd-widget' ); ?></label>
                            </th>
                            <td>
                                <input type="text" id="utw_color_hover"
                                       name="untappd_widget_options[colors][hover_bg]"
                                       value="<?php echo esc_attr( $opts['colors']['hover_bg'] ); ?>"
                                       class="regular-text" placeholder="rgba(0,0,0,0.03)" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="utw_radius"><?php esc_html_e( 'Border radius', 'untappd-widget' ); ?></label>
                            </th>
                            <td>
                                <input type="text" id="utw_radius"
                                       name="untappd_widget_options[colors][radius]"
                                       value="<?php echo esc_attr( $opts['colors']['radius'] ); ?>"
                                       class="small-text" placeholder="8px" />
                                <p class="description"><?php esc_html_e( 'Any valid CSS length — e.g. 8px, 0.5rem, 0.', 'untappd-widget' ); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>

                <?php submit_button( __( 'Save Settings', 'untappd-widget' ) ); ?>
            </form>

            <!-- ── Cache management (separate action) ─────────────────── -->
            <div class="utw-card">
                <h2 class="utw-card__title"><?php esc_html_e( 'Cache', 'untappd-widget' ); ?></h2>
                <p class="description">
                    <?php esc_html_e( 'The plugin caches API responses to reduce requests. Use the button below to force a fresh fetch immediately.', 'untappd-widget' ); ?>
                </p>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <input type="hidden" name="action" value="untappd_flush_cache" />
                    <?php wp_nonce_field( self::NONCE ); ?>
                    <?php submit_button( __( 'Flush Cache Now', 'untappd-widget' ), 'secondary', 'submit', false ); ?>
                </form>
            </div>

        </div><!-- .utw-wrap -->

        <style>
        .utw-wrap { max-width: 800px; }
        .utw-card {
            background: #fff;
            border: 1px solid #c3c4c7;
            border-radius: 4px;
            padding: 16px 20px 8px;
            margin-bottom: 20px;
        }
        .utw-card__title {
            margin: 0 0 12px;
            padding-bottom: 10px;
            border-bottom: 1px solid #f0f0f1;
            font-size: 14px;
            font-weight: 600;
        }
        .utw-card .form-table th { width: 220px; }
        </style>
        <?php
    }
}

new Untappd_Widget_Settings_Page();

// =============================================================================
// Widget
// =============================================================================

class Untappd_Brewery_Widget extends WP_Widget {

    const CACHE_KEY_PREFIX = 'untappd_checkins_';

    public function __construct() {
        parent::__construct(
            'untappd_brewery_widget',
            __( 'Untappd Brewery Check-ins', 'untappd-widget' ),
            [
                'description'          => __( 'Displays the latest check-ins for a brewery from Untappd.', 'untappd-widget' ),
                'classname'            => 'untappd-brewery-widget',
                'show_instance_in_rest' => true,
            ]
        );

        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_shortcode( 'untappd_checkins', [ $this, 'shortcode' ] );
    }

    // -------------------------------------------------------------------------
    // Frontend output
    // -------------------------------------------------------------------------

    public function widget( $args, $instance ) {
        $global = untappd_widget_options();

        // Per-widget overrides: title and optional brewery_id
        $title      = ! empty( $instance['title'] )      ? sanitize_text_field( $instance['title'] )  : __( 'Latest Check-ins', 'untappd-widget' );
        $brewery_id = ! empty( $instance['brewery_id'] ) ? absint( $instance['brewery_id'] )           : absint( $global['brewery_id'] );

        $client_id     = $global['client_id'];
        $client_secret = $global['client_secret'];
        $count         = absint( $global['count'] );
        $min_rating    = (float) $global['min_rating'];
        $show          = $global['show'];
        $colors        = $global['colors'];
        $cache_seconds = absint( $global['cache_minutes'] ) * 60;

        if ( ! $brewery_id || ! $client_id || ! $client_secret ) {
            if ( current_user_can( 'manage_options' ) ) {
                echo $args['before_widget'];
                echo '<p class="untappd-config-notice">'
                    . esc_html__( 'Untappd Widget: configure your credentials in Settings → Untappd Widget.', 'untappd-widget' )
                    . '</p>';
                echo $args['after_widget'];
            }
            return;
        }

        $checkins = $this->fetch_checkins( $brewery_id, $client_id, $client_secret, 25, $cache_seconds );

        if ( ! is_wp_error( $checkins ) && $min_rating > 0 ) {
            $checkins = array_values( array_filter( $checkins, function ( $c ) use ( $min_rating ) {
                return isset( $c['rating_score'] ) && (float) $c['rating_score'] >= $min_rating;
            } ) );
        }

        $checkins = is_array( $checkins ) ? array_slice( $checkins, 0, $count ) : $checkins;

        if ( is_wp_error( $checkins ) ) {
            if ( current_user_can( 'manage_options' ) ) {
                echo $args['before_widget'];
                echo '<p class="untappd-config-notice">' . esc_html( $checkins->get_error_message() ) . '</p>';
                echo $args['after_widget'];
            }
            return;
        }

        if ( empty( $checkins ) ) {
            echo $args['before_widget'];
            echo '<p class="untappd-empty">' . esc_html__( 'No check-ins found.', 'untappd-widget' ) . '</p>';
            echo $args['after_widget'];
            return;
        }

        echo $args['before_widget'];
        $this->output_color_vars( $colors );

        echo '<div class="untappd-widget-inner">';

        echo '<div class="untappd-widget-header">';
        echo '<span class="untappd-widget-icon">' . $this->svg_hop() . '</span>';
        echo $args['before_title'] . esc_html( $title ) . $args['after_title'];
        echo '</div>';

        $carousel_visible = absint( $global['carousel_visible'] );
        echo '<div class="utw-carousel" data-visible="' . $carousel_visible . '" style="--utw-visible:' . $carousel_visible . '">';
        echo '<div class="utw-carousel-viewport">';
        echo '<ul class="untappd-checkins" role="list">';
        foreach ( $checkins as $checkin ) {
            $this->render_checkin( $checkin, $show );
        }
        echo '</ul>';
        echo '</div>'; // .utw-carousel-viewport
        echo '</div>'; // .utw-carousel

        echo '<a class="untappd-view-all" href="' . esc_url( 'https://untappd.com/brewery/' . $brewery_id ) . '" target="_blank" rel="noopener noreferrer">';
        echo $this->svg_untappd();
        echo '<span>' . esc_html__( 'View on Untappd', 'untappd-widget' ) . '</span>';
        echo '</a>';

        echo '</div>'; // .untappd-widget-inner
        echo $args['after_widget'];
    }

    /**
     * Output a single <style> block that overrides the CSS variables saved in settings.
     * The static flag ensures this runs at most once per page, even with multiple widget instances.
     */
    private function output_color_vars( array $colors ) {
        static $done = false;
        if ( $done ) {
            return;
        }
        $done = true;

        $map = [
            'amber'     => '--utw-amber',
            'border'    => '--utw-border',
            'separator' => '--utw-separator',
            'hover_bg'  => '--utw-hover-bg',
            'radius'    => '--utw-radius',
        ];

        $vars = '';
        foreach ( $map as $key => $prop ) {
            if ( ! empty( $colors[ $key ] ) ) {
                $vars .= $prop . ':' . $colors[ $key ] . ';';
            }
        }

        if ( $vars ) {
            echo '<style>.untappd-brewery-widget{' . $vars . '}</style>' . "\n";
        }
    }

    private function render_checkin( array $checkin, array $show ) {
        $beer_name  = $checkin['beer']['beer_name']        ?? '';
        $beer_style = $checkin['beer']['beer_style']       ?? '';
        $beer_label = $checkin['beer']['beer_label']       ?? '';
        $user_name  = $checkin['user']['user_name']        ?? '';
        $first_name = $checkin['user']['first_name']       ?? '';
        $last_name  = $checkin['user']['last_name']        ?? '';
        $avatar     = $checkin['user']['user_avatar']      ?? '';
        $rating     = isset( $checkin['rating_score'] ) && $checkin['rating_score'] > 0 ? (float) $checkin['rating_score'] : null;
        $comment    = $checkin['checkin_comment']          ?? '';
        $created_at = $checkin['created_at']               ?? '';
        $checkin_id = absint( $checkin['checkin_id']       ?? 0 );

        $full_name    = trim( "$first_name $last_name" ) ?: $user_name;
        $initials     = mb_strtoupper( mb_substr( $full_name, 0, 1 ) );
        $date_display = '';
        if ( $created_at ) {
            $ts           = strtotime( $created_at );
            $date_display = $ts ? human_time_diff( $ts, time() ) . ' ' . __( 'ago', 'untappd-widget' ) : '';
        }

        $photo_url = $checkin['media']['items'][0]['photo']['photo_img_md'] ?? '';

        $checkin_url = $checkin_id ? "https://untappd.com/user/{$user_name}/checkin/{$checkin_id}" : '';

        echo '<li class="untappd-checkin">';

        // Avatar
        if ( ! empty( $show['avatar'] ) ) {
            echo '<div class="untappd-checkin__avatar">';
            if ( $avatar ) {
                echo '<img src="' . esc_url( $avatar ) . '" alt="' . esc_attr( $full_name ) . '" loading="lazy" width="44" height="44" />';
            } else {
                echo '<div class="untappd-checkin__avatar-placeholder" aria-hidden="true">' . esc_html( $initials ) . '</div>';
            }
            echo '</div>';
        }

        echo '<div class="untappd-checkin__body">';

        // User + time
        if ( ! empty( $show['username'] ) || ! empty( $show['timestamp'] ) ) {
            echo '<div class="untappd-checkin__meta">';
            if ( ! empty( $show['username'] ) ) {
                echo '<span class="untappd-checkin__user">' . esc_html( $full_name ) . '</span>';
            }
            if ( ! empty( $show['timestamp'] ) && $date_display ) {
                echo '<time class="untappd-checkin__time" datetime="' . esc_attr( $created_at ) . '">' . esc_html( $date_display ) . '</time>';
            }
            echo '</div>';
        }

        // Beer row
        if ( ! empty( $show['beer_label'] ) || ! empty( $show['beer_name'] ) || ! empty( $show['beer_style'] ) ) {
            echo '<div class="untappd-checkin__beer">';
            if ( ! empty( $show['beer_label'] ) && $beer_label ) {
                echo '<img class="untappd-checkin__beer-label" src="' . esc_url( $beer_label ) . '" alt="" loading="lazy" width="36" height="36" />';
            }
            echo '<div class="untappd-checkin__beer-text">';
            if ( ! empty( $show['beer_name'] ) ) {
                if ( $checkin_url ) {
                    echo '<a class="untappd-checkin__beer-name" href="' . esc_url( $checkin_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $beer_name ) . '</a>';
                } else {
                    echo '<span class="untappd-checkin__beer-name">' . esc_html( $beer_name ) . '</span>';
                }
            }
            if ( ! empty( $show['beer_style'] ) && $beer_style ) {
                echo '<span class="untappd-checkin__beer-style">' . esc_html( $beer_style ) . '</span>';
            }
            echo '</div>';
            echo '</div>';
        }

        // Rating
        if ( ! empty( $show['rating'] ) && $rating !== null ) {
            echo '<div class="untappd-checkin__rating">';
            echo $this->render_stars( $rating );
            echo '<span class="untappd-checkin__rating-num">' . number_format( $rating, 2 ) . '</span>';
            echo '</div>';
        }

        // Comment
        if ( ! empty( $show['comment'] ) && $comment ) {
            echo '<blockquote class="untappd-checkin__comment">' . esc_html( $comment ) . '</blockquote>';
        }

        // Photo
        if ( ! empty( $show['photo'] ) && $photo_url ) {
            echo '<img class="untappd-checkin__photo" src="' . esc_url( $photo_url ) . '" alt="" loading="lazy" />';
        }

        echo '</div>'; // .body
        echo '</li>';
    }

    private function render_stars( float $rating ): string {
        $html = '<span class="untappd-stars" aria-label="' . esc_attr( number_format( $rating, 2 ) . ' out of 5' ) . '" role="img">';
        for ( $i = 1; $i <= 5; $i++ ) {
            if ( $rating >= $i ) {
                $mod = 'full';
            } elseif ( $rating >= $i - 0.5 ) {
                $mod = 'half';
            } else {
                $mod = 'empty';
            }
            $html .= '<span class="untappd-star untappd-star--' . $mod . '" aria-hidden="true">&#9733;</span>';
        }
        $html .= '</span>';
        return $html;
    }

    // -------------------------------------------------------------------------
    // Inline SVGs
    // -------------------------------------------------------------------------

    private function svg_hop(): string {
        return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M17 8C8 10 5.9 16.17 3.82 21.34L5.71 22l1-2.3A4.49 4.49 0 0 0 8 20C19 20 22 3 22 3c-1 2-8 4-11 8l-1.5-1.5C10.6 8.1 14 6 17 8z"/></svg>';
    }

    private function svg_untappd(): string {
        return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z"/></svg>';
    }

    private function svg_chevron( string $dir ): string {
        $d = $dir === 'left' ? 'M15 18l-6-6 6-6' : 'M9 18l6-6-6-6';
        return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="' . $d . '"/></svg>';
    }

    // -------------------------------------------------------------------------
    // Assets
    // -------------------------------------------------------------------------

    public function enqueue_assets() {
        wp_enqueue_style(
            'untappd-brewery-widget',
            plugin_dir_url( __FILE__ ) . 'untappd-widget.css',
            [],
            '1.3.0'
        );
        wp_enqueue_script(
            'untappd-brewery-widget',
            plugin_dir_url( __FILE__ ) . 'untappd-widget.js',
            [],
            '1.3.0',
            true
        );
    }

    // -------------------------------------------------------------------------
    // Shortcode: [untappd_checkins brewery_id="123" count="5" title="..."]
    // -------------------------------------------------------------------------

    public function shortcode( $atts ): string {
        $global = untappd_widget_options();

        $atts = shortcode_atts( [
            'brewery_id' => $global['brewery_id'],
            'title'      => __( 'Latest Check-ins', 'untappd-widget' ),
            'count'      => $global['count'],
            'visible'    => $global['carousel_visible'],
        ], $atts, 'untappd_checkins' );

        $brewery_id       = absint( $atts['brewery_id'] );
        $title            = sanitize_text_field( $atts['title'] );
        $count            = min( 25, max( 1, absint( $atts['count'] ) ) );
        $carousel_visible = min(  5, max( 1, absint( $atts['visible'] ) ) );
        $client_id     = $global['client_id'];
        $client_secret = $global['client_secret'];
        $min_rating    = (float) $global['min_rating'];
        $show          = $global['show'];
        $colors        = $global['colors'];
        $cache_seconds = absint( $global['cache_minutes'] ) * 60;

        if ( ! $brewery_id || ! $client_id || ! $client_secret ) {
            if ( current_user_can( 'manage_options' ) ) {
                return '<p class="untappd-config-notice">'
                    . esc_html__( 'Untappd Widget: configure your credentials in Settings → Untappd Widget.', 'untappd-widget' )
                    . '</p>';
            }
            return '';
        }

        $checkins = $this->fetch_checkins( $brewery_id, $client_id, $client_secret, 25, $cache_seconds );

        if ( is_wp_error( $checkins ) ) {
            if ( current_user_can( 'manage_options' ) ) {
                return '<p class="untappd-config-notice">' . esc_html( $checkins->get_error_message() ) . '</p>';
            }
            return '';
        }

        if ( $min_rating > 0 ) {
            $checkins = array_values( array_filter( $checkins, function ( $c ) use ( $min_rating ) {
                return isset( $c['rating_score'] ) && (float) $c['rating_score'] >= $min_rating;
            } ) );
        }

        $checkins = array_slice( $checkins, 0, $count );

        if ( empty( $checkins ) ) {
            return '<p class="untappd-empty">' . esc_html__( 'No check-ins found.', 'untappd-widget' ) . '</p>';
        }

        ob_start();

        echo '<div class="untappd-brewery-widget">';
        $this->output_color_vars( $colors );
        echo '<div class="untappd-widget-inner">';

        echo '<div class="untappd-widget-header">';
        echo '<span class="untappd-widget-icon">' . $this->svg_hop() . '</span>';
        echo '<h2 class="widget-title">' . esc_html( $title ) . '</h2>';
        echo '</div>';

        echo '<div class="utw-carousel" data-visible="' . $carousel_visible . '" style="--utw-visible:' . $carousel_visible . '">';
        echo '<div class="utw-carousel-viewport">';
        echo '<ul class="untappd-checkins" role="list">';
        foreach ( $checkins as $checkin ) {
            $this->render_checkin( $checkin, $show );
        }
        echo '</ul>';
        echo '</div>'; // .utw-carousel-viewport
        echo '</div>'; // .utw-carousel

        echo '<a class="untappd-view-all" href="' . esc_url( 'https://untappd.com/brewery/' . $brewery_id ) . '" target="_blank" rel="noopener noreferrer">';
        echo $this->svg_untappd();
        echo '<span>' . esc_html__( 'View on Untappd', 'untappd-widget' ) . '</span>';
        echo '</a>';

        echo '</div>'; // .untappd-widget-inner
        echo '</div>'; // .untappd-brewery-widget

        return ob_get_clean();
    }

    // -------------------------------------------------------------------------
    // Untappd API
    // -------------------------------------------------------------------------

    /**
     * @return array|WP_Error
     */
    private function fetch_checkins( int $brewery_id, string $client_id, string $client_secret, int $count, int $cache_seconds ) {
        $cache_key = self::CACHE_KEY_PREFIX . $brewery_id;
        $cached    = get_transient( $cache_key );

        if ( $cached !== false ) {
            return array_slice( $cached, 0, $count );
        }

        $url = add_query_arg(
            [
                'client_id'     => $client_id,
                'client_secret' => $client_secret,
            ],
            "https://api.untappd.com/v4/brewery/checkins/{$brewery_id}"
        );

        $response = wp_remote_get( $url, [
            'timeout' => 15,
            'headers' => [ 'Accept' => 'application/json' ],
        ] );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        if ( $code !== 200 ) {
            $msg = $data['meta']['error_detail'] ?? sprintf( __( 'Untappd API returned HTTP %d.', 'untappd-widget' ), $code );
            return new WP_Error( 'untappd_api_error', $msg );
        }

        $checkins = $data['response']['checkins']['items'] ?? [];
        set_transient( $cache_key, $checkins, $cache_seconds );

        return array_slice( $checkins, 0, $count );
    }

    // -------------------------------------------------------------------------
    // Admin widget form (simplified — all main settings live in the Settings page)
    // -------------------------------------------------------------------------

    public function form( $instance ) {
        $title      = ! empty( $instance['title'] )      ? $instance['title']      : __( 'Latest Check-ins', 'untappd-widget' );
        $brewery_id = ! empty( $instance['brewery_id'] ) ? $instance['brewery_id'] : '';
        $global     = untappd_widget_options();
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>">
                <?php esc_html_e( 'Widget Title', 'untappd-widget' ); ?>
            </label>
            <input class="widefat"
                   id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>"
                   type="text"
                   value="<?php echo esc_attr( $title ); ?>" />
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'brewery_id' ) ); ?>">
                <?php esc_html_e( 'Brewery ID (optional override)', 'untappd-widget' ); ?>
            </label>
            <input class="widefat"
                   id="<?php echo esc_attr( $this->get_field_id( 'brewery_id' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'brewery_id' ) ); ?>"
                   type="number"
                   min="1"
                   step="1"
                   placeholder="<?php echo esc_attr( $global['brewery_id'] ? $global['brewery_id'] : __( 'from Settings page', 'untappd-widget' ) ); ?>"
                   value="<?php echo esc_attr( $brewery_id ); ?>" />
            <small style="display:block;color:#888;margin-top:3px;font-size:11px;">
                <?php esc_html_e( 'Leave blank to use the brewery set in Settings → Untappd Widget.', 'untappd-widget' ); ?>
            </small>
        </p>

        <p style="margin-top:10px;">
            <a href="<?php echo esc_url( admin_url( 'options-general.php?page=untappd-widget-settings' ) ); ?>">
                <?php esc_html_e( '⚙ Manage all settings →', 'untappd-widget' ); ?>
            </a>
        </p>
        <?php
    }

    // -------------------------------------------------------------------------
    // Sanitize & save (per-widget)
    // -------------------------------------------------------------------------

    public function update( $new_instance, $old_instance ) {
        $instance               = [];
        $instance['title']      = sanitize_text_field( $new_instance['title'] );
        $instance['brewery_id'] = absint( $new_instance['brewery_id'] );

        if ( $instance['brewery_id'] ) {
            delete_transient( self::CACHE_KEY_PREFIX . $instance['brewery_id'] );
        }
        if ( ! empty( $old_instance['brewery_id'] ) ) {
            delete_transient( self::CACHE_KEY_PREFIX . absint( $old_instance['brewery_id'] ) );
        }

        return $instance;
    }
}

add_action( 'widgets_init', function () {
    register_widget( 'Untappd_Brewery_Widget' );
} );
